package com.capgemini.libservlet.dao;

import com.capgemini.libservlet.model.Book;
import com.capgemini.libservlet.model.Library;

public interface LibraryDao {
	public void addBook(Book b);
	public Book searchBook(int bookId);
	public void deleteBook(int bookId);
	public Book updateBook(int bookid,String bname,String author,String publisher);
	public Library getLibrary(String libraryName) ;
}
