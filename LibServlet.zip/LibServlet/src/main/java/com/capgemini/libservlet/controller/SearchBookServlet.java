package com.capgemini.libservlet.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.libservlet.dao.LibraryDao;
import com.capgemini.libservlet.dao.LibraryDaoImpl;
import com.capgemini.libservlet.model.Book;

public class SearchBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private LibraryDaoImpl libraryDaoImpl;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		Book book = libraryDaoImpl.searchBook(Integer.parseInt(request.getParameter("bookId")));
		if(book!=null) {
			out.println("Book Id : "+book.getBookId());
			out.print("<br>");
			out.println("Book Name : "+book.getBookName());
			out.print("<br>");
			out.println("Author of Book : "+book.getAuthor());
			out.print("<br>");
			out.println("Publisher of Book : "+book.getPublisher());
		}
		else 
		{
			out.println("No such bookid");
		}
	}
}
