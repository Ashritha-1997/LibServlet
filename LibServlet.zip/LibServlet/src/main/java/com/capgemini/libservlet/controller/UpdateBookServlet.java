package com.capgemini.libservlet.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.libservlet.dao.LibraryDao;
import com.capgemini.libservlet.dao.LibraryDaoImpl;
import com.capgemini.libservlet.model.Book;

public class UpdateBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	private LibraryDaoImpl libraryDaoImpl;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		response.setContentType("text/html");	
		int bId = Integer.parseInt(request.getParameter("bookId"));
		String newBname = request.getParameter("bname");
		String newAuthor = request.getParameter("author");
		String newPublisher = request.getParameter("publisher");
		
		Book book = libraryDaoImpl.searchBook(bId);
		
	     out.println("<html>");
		 out.println("<body>");
			
		Book updatebook = libraryDaoImpl.updateBook(bId,newBname,newAuthor,newPublisher);
		 	
			out.println("After Update");out.print("<br>");
			out.print("<br>");
			out.println("Book Name : " +updatebook.getBookName());
			out.print("<br>");
			out.println(" Author : "+updatebook.getAuthor());
			out.print("<br>");
			out.println(" Publisher : "+updatebook.getPublisher());
			out.print("<br>");
			
		out.println("</html>");
		out.println("</body>");
	}

}
