package com.capgemini.libservlet.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.capgemini.libservlet.model.Book;
import com.capgemini.libservlet.model.Library;


public class LibraryDaoImpl implements LibraryDao{
	private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("TestPersistence");
	private static EntityManager em = emf.createEntityManager();

	@Override
	public void addBook(Book b) {
		em.getTransaction().begin();
		em.persist(b);
		em.getTransaction().commit();
		
	}

	@Override
	public Book searchBook(int bookId) {
		return em.find(Book.class,bookId);
	}

	@Override
	public void deleteBook(int bookId) {
		em.getTransaction().begin();
		Book b = searchBook(bookId);
		em.remove(b);
		em.getTransaction().commit();
		
	}

	@Override
	public Book updateBook(int bookid, String bname, String author, String publisher) {
		Book book = searchBook(bookid);
		em.getTransaction().begin();
		if(bname.length()!=0) {
			book.setBookName(bname);
		}
		if(author.length()!=0) {
			book.setAuthor(author);
		}
		if(publisher.length()!=0) {
			book.setPublisher(publisher);
		}
		em.getTransaction().commit();
		return book;
	}
	
	public Library getLibrary(String libraryName) {
		EntityManager e1 = emf.createEntityManager();
		
		TypedQuery<Library> q = e1.createQuery("SELECT l FROM library l", Library.class);
		List<Library> lib = q.getResultList();
		
		for(Library li : lib ) {
			if(li.getLibraryName().equals(libraryName)) {
				return li;
			}
		}
		return null;
	}
	
}
