package com.capgemini.libservlet.controller;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.libservlet.dao.LibraryDao;
import com.capgemini.libservlet.dao.LibraryDaoImpl;
import com.capgemini.libservlet.model.Book;
import com.capgemini.libservlet.model.Library;

@WebServlet("/addbook")
public class AddBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private LibraryDaoImpl libraryDaoImpl;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		Book book = new Book();
		String libname = request.getParameter("library");
		Library library = libraryDaoImpl.getLibrary(libname);
		book.setLibrary(library);
		
		book.setBookId(Integer.parseInt(request.getParameter("bookId")));
		book.setBookName(request.getParameter("bname"));
		book.setAuthor(request.getParameter("author"));
		book.setPublisher(request.getParameter("publisher"));
		
		libraryDaoImpl.addBook(book);
		out.println("Book added successfully");
		


	}



}
